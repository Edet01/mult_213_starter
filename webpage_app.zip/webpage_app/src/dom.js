export function renderMessage(el, text) {
  el.innerHTML = `<p>${text}</p>`;
}
